module.exports = {
    project: {
        ios: {},
        android: {},
    },
    assets: ['./Assets/font/mustardo.ttf']
};